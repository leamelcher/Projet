package parking;
import vehicule.*;

public class Parking {
	private Vehicule[] vehicule;
	private int placesMax;
	private int placesOccup;
	
	public Parking(int lesPlacesMax) {
	this.placesMax = lesPlacesMax;
	this.vehicule = new Vehicule[lesPlacesMax];
	this.placesOccup = 0;
	}
	
	public void ajouter(Vehicule veh) {
	this.vehicule[this.placesOccup] = veh;
	this.placesOccup ++;
	}
	
	public boolean plein() {
	return (this.placesOccup == this.placesMax);
	}
	
	public String toString() {
	String res="";
	for (int i = 0; i < this.placesOccup; i++) {
	res = (res +"\n"+this.vehicule[i].toString()+"\n"+this.placesOccup+"\n"+this.placesMax);
	}
	return res;
	}
	
}
