import vehicule.*; //Premiere méthode pour prendre toutes les classes d'un package.
import parking.Parking; //Deuxieme méthode pour écrire la classe quand on en prend qu'une

public class TestVehicule {
	public static void main(String[] args) {
		Voiture voi = new Voiture("rr584","jaune","modele1");
		Velo vel = new Velo("orange", "modele2", 2);
		Parking park = new Parking(120);
		Camion cam = new Camion("rouge", "modele3", 110);
			if (!park.plein()) {
		park.ajouter(cam);
		park.ajouter(voi);
		park.ajouter(vel);
		}
		System.out.println(park.toString());
	
	
	}



}
