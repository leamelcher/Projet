package vehicule;

public class Voiture extends Vehicule {
	private String numImmat;
	
	public Voiture(String leNumImmat, String lacouleur, String lemodele) {
	super(lacouleur, lemodele); //Le super doit toujours etre en premier.
	this.numImmat = leNumImmat;
	}
	
	public String toString() {
	return super.toString()+""+this.numImmat;
	}
}
