package vehicule;

public class Velo extends Vehicule {
	private int taille;
	
	public Velo(String lacouleur, String lemodele, int laTaille) {
	super(lacouleur, lemodele);
	this.taille = laTaille;
	}
	
	public String toString() {
	return super.toString()+""+this.taille;
	}
}
