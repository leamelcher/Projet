package vehicule;

public class Camion extends Vehicule {
	private int poidsTotal;
	
	public Camion(String lemodele, String lacouleur, int lepoidsTotal) {
		super(lacouleur, lemodele);
		this.poidsTotal = lepoidsTotal;
	}
	
	public String toString() {
	return super.toString()+""+this.poidsTotal;
	}
}
