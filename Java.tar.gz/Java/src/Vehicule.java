package vehicule;

public abstract class Vehicule {
	private String couleur;
	private String modele;
	
	public Vehicule(String lacouleur, String lemodele) {
	this.couleur = lacouleur;
	this.modele = lemodele;
	}
	
	public String toString() {
	return this.couleur+""+this.modele;
	}
}
